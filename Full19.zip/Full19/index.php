<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<title>Innovation</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css" />
	<script type="text/javascript" src="js/jquery-1.6.2.min.js"></script>
	<script type="text/javascript" src="js/input_jquery.js"></script>
	<!--[if IE 6]>
	<link rel="stylesheet" type="text/css" href="css/ie6.css" />
	<![endif]-->
	<!--[if IE 7]>
	<link rel="stylesheet" type="text/css" href="css/ie7.css" />
	<![endif]-->
	<!--[if IE 8]>
	<link rel="stylesheet" type="text/css" href="css/ie8.css" />
	<![endif]-->
	<script type="text/javascript" src="js/jquery.infinitecarousel.js"></script>
	<script type="text/javascript">
		$(function(){
			$('#carousel').infiniteCarousel({
				displayTime: 4000
			});
		});
	</script>
	<link rel="stylesheet" type="text/css" href="css/slider.css" /> 
</head>
<body>
<?php include("include/index/header.php"); ?>
<?php include("include/index/menu.php"); ?>
<?php include("include/index/main.php"); ?>
<?php include("include/index/footer.php"); ?>
</body>
</html>
