(function ($) {
$.fn.textShadow = function(shadowcolor,x,y) {
return this.each(function(i){
var parent = "tsw-" + Math.floor(Math.random()*100000);
//Create container
$(this).wrap('<div class="text-shadow-wrapper" id="' + parent + '"></div>');
//Set height of container so that it properly overflows
$("#" + parent).css("height", $(this).css("font-size")); //Math.abs()??
//Add text-shadow class to initial element
$(this).addClass("text-shadow");
//Adds shadow HTML element
$(this).before('<span class="shadow">' + $(this).text() + '</span>');
//Positions shadow HTML element
$("#" + parent + " .shadow").css({left: x, top: y, color: shadowcolor});
});
};
})(jQuery);