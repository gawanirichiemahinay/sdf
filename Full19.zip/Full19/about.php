<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<title>Innovation</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css" />
	<link rel="stylesheet" type="text/css" href="css/inner.css" />
	<script type="text/javascript" src="js/jquery-1.6.2.min.js"></script>
	<script type="text/javascript" src="js/input_jquery.js"></script>
	<!--[if IE 6]>
	<link rel="stylesheet" type="text/css" href="css/ie6.css" />
	<![endif]-->
	<!--[if IE 7]>
	<link rel="stylesheet" type="text/css" href="css/ie7.css" />
	<![endif]-->
	<!--[if IE 8]>
	<link rel="stylesheet" type="text/css" href="css/ie8.css" />
	<![endif]-->
</head>
<body>
<?php include("include/about/header.php"); ?>
<?php include("include/about/menu.php"); ?>
<?php include("include/about/main.php"); ?>
<?php include("include/about/footer.php"); ?>
</body>
</html>
