<div id="footer_wrap">
					<div class="footer_nav">
						<ul>
							<li class="first"><a href="index.php">Home</a></li>
							<li><a href="about.php">About</a></li>
							<li><a href="#">Product</a></li>
							<li><a href="#">Service</a></li>
							<li><a href="#">FAQs</a></li>
							<li><a href="#">Contacts</a></li>
							<li class="last"><a href="#">Privacy</a></li>
						</ul>
						<p class="copyright">All content &#169; 2010 bizsolutions.com. All Rights Reserve</p>
					</div>
					<div class="social_network">
						<p>Find us on:</p>
						<a href="#"><img src="images/sn_icons_01.gif" alt="Social Network Icon 1" /></a>
						<a href="#"><img src="images/sn_icons_02.gif" alt="Social Network Icon 2" /></a>
						<a href="#"><img src="images/sn_icons_03.gif" alt="Social Network Icon 3" /></a>
						<a href="#"><img src="images/sn_icons_04.gif" alt="Social Network Icon 4" /></a>
						<a href="#"><img src="images/sn_icons_05.gif" alt="Social Network Icon 5" /></a>
						<a href="#"><img src="images/sn_icons_06.gif" alt="Social Network Icon 6" /></a>
					</div>
			</div><!-- End of Footer Wrap -->
		</div>