<div id="carousel">
				<ul>
					<li>
						<div class="slider_content">
							<div class="slider_text">
								<h2>Your way  to <span>Success!</span></h2>
								<p class="subtitle"><span>Together</span> we bring your business on top</p>
								<p class="text_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
								<a href="#" class="btn1">Learn more</a>
								<a href="#" class="btn2">Join us now!</a>
							</div>
						</div>
						<img src="images/main_visual.png" alt="Main Visual" class="slide" />
					</li>
					<li>
						<div class="slider_content">
							<div class="slider_text">
								<h2>Your way  to <span>Success!</span></h2>
								<p class="subtitle"><span>Together</span> we bring your business on top</p>
								<p class="text_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
								<a href="#" class="btn1">Learn more</a>
								<a href="#" class="btn2">Join us now!</a>
							</div>
						</div>
						<img src="images/main_visual.png" alt="Main Visual" class="slide" />
					</li>
					<li>
						<div class="slider_content">
							<div class="slider_text">
								<h2>Your way  to <span>Success!</span></h2>
								<p class="subtitle"><span>Together</span> we bring your business on top</p>
								<p class="text_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
								<a href="#" class="btn1">Learn more</a>
								<a href="#" class="btn2">Join us now!</a>
							</div>
						</div>
						<img src="images/main_visual.png" alt="Main Visual" class="slide" />
					</li>
				</ul>
			</div>
			<div id="menu_wrap">
				<ul class="main_menu">
					  <li class="current"><a href="index.php">Home</a></li>
					  <li><a href="about.php">About</a></li>
					  <li><a href="#">Product</a></li>
					  <li><a href="#">Service</a></li>
					  <li><a href="#">FAQs</a></li>
					  <li><a href="#">Contacts</a></li>
					  <li><a href="#">Privacy</a></li>
					  <li>
						<form action="#" method="post" class="search_frm">
							<input type="text" value="Search..." class="textbox" />
							<input type="submit" class="search_btn" value="" />
						</form>
					 </li>
				</ul>
			</div>