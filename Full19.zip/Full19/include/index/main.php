<div id="content_wrap">
				<div class="featured_section">
					<div class="wrapper">
						<ul class="content">
							<li>
								<div>
									<img src="images/thumbnail_01_.gif" alt="Thumbnail 01" />
									<h3>Nemo en ipsam voluptatem quia.</h3>
									<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
								</div>
							</li>
							<li>
								<div>
									<img src="images/thumbnail_02_.gif" alt="Thumbnail 02" />
									<h3>Nemo en ipsam voluptatem quia.</h3>
									<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
								</div>
							</li>
							<li>
								<div>
									<img src="images/thumbnail_03_.gif" alt="Thumbnail 03" />
									<h3>Nemo en ipsam voluptatem quia.</h3>
									<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
								</div>
							</li>
						</ul>
					</div>
				</div>
				<div class="newsletter">
					<div class="wrapper_2">
						<div class="image">
							<img src="images/img_01.gif" class="img_1" alt="Newsletter"  />
						</div>
						<p class="highlight">Europan lingues membres.</p>
						<div class="content">
						<p class="title">Nemo en ipsam voluptatem quia.</p>
						<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.</p>
						<p class="subscribe"><a href="#"><span>Subscribe Now!</span></a></p>
						</div>
						<div class="content">
							<p class="title">Nemo en ipsam voluptatem quia.</p>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.</p>
							<p class="subscribe"><a href="#"><span>Subscribe Now!</span></a></p>
						</div>
					</div>
				</div>
			</div>