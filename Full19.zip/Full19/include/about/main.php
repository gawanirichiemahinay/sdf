<div id="content_wrap">
				<div class="top_section" >
					<h2>Bringing everything to Life!</h2>
					<p class="sub_text">Nemo enim ipsam voluptatem quia voluptas sit.</p>
					<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae.</p>
				</div>
				<ul class="list">
					<li>
						<div class="box">
							<p class="title">Nemo enim ipsam voluptatem.</p>
							<p>Li Europan lingues es membres del sam familie. Lor separat existentie es un myth. Por scientie, musica, sport etc, litot Europa usa li sam vocabular. Li lingues differe solmen in li grammatica.</p>
						</div>
						<div class="box">
							<p class="title">Nemo enim ipsam voluptatem.</p>
							<p>Li Europan lingues es membres del sam familie. Lor separat existentie es un myth. Por scientie, musica, sport etc, litot Europa usa li sam vocabular. Li lingues differe solmen in li grammatica.</p>
						</div>
						<div class="box">
							<p class="title">Nemo enim ipsam voluptatem.</p>
							<p>Li Europan lingues es membres del sam familie. Lor separat existentie es un myth. Por scientie, musica, sport etc, litot Europa usa li sam vocabular. Li lingues differe solmen in li grammatica.</p>
						</div>
					</li>
					<li class="img_3"><img src="images/img_03.gif" alt="Networking" /></li>
					<li>
						<div class="box">
							<p class="title">Nemo enim ipsam voluptatem.</p>
							<p>Li Europan lingues es membres del sam familie. Lor separat existentie es un myth. Por scientie, musica, sport etc, litot Europa usa li sam vocabular. Li lingues differe solmen in li grammatica.</p>
						</div>
						<div class="box">
							<p class="title">Nemo enim ipsam voluptatem.</p>
							<p>Li Europan lingues es membres del sam familie. Lor separat existentie es un myth. Por scientie, musica, sport etc, litot Europa usa li sam vocabular. Li lingues differe solmen in li grammatica.</p>
						</div>
						<div class="box">
							<p class="title">Nemo enim ipsam voluptatem.</p>
							<p>Li Europan lingues es membres del sam familie. Lor separat existentie es un myth. Por scientie, musica, sport etc, litot Europa usa li sam vocabular. Li lingues differe solmen in li grammatica.</p>
						</div>
					</li>
				</ul>
				<div class="newsletter">
					<div class="wrapper_2">
						<div class="image">
							<img src="images/img_02.gif" class="img_2" alt="Connect"  />
						</div>
						<p class="highlight_2">Sed ut perspiciatis unde omnis iste natus error sit.</p>
						<p>Li Europan lingues es membres del sam familie. Lor separat existentie es un myth. Por scientie, musica, sport etc, litot Europa usa li sam vocabular. Li lingues differe solmen in li grammatica.</p>
						<p class="text">Por scientie, musica, sport etc, litot Europa usa li sam vocabular.</p>
					</div>
				</div>
			</div> 