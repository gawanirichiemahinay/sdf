<div id="wrapper">
			<div id="header">
				<h1><a href="#"><img src="images/logo.gif" alt="Logo Innovation" /></a></h1>
				<div class="right_section">
					<div class="topmenu">
						<a href="#" class="first">NEWS</a>
						<a href="#" class="last">PRODUCT REGISTRATION</a>
					</div>
					<div class="registration_wrap">
						<p class="signup last"><a href="#">SIGN UP!</a> FOR EMAIL UPDATES</p>
					</div>
				</div>
			</div>